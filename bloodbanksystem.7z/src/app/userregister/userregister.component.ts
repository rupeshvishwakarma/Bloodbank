import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/public_api';

import { UserService } from './user.service';
import { User } from '../model/user';

@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css']
})
export class UserregisterComponent implements OnInit {

  datePickerConfig: Partial<BsDatepickerConfig>

  user: User = new User();
  submitted: boolean = false;

  constructor(private userService: UserService) {
    this.datePickerConfig = Object.assign({},
      {
        maxDate: new Date(2019, 10, 13),
        dateInputFormat: 'DD/MM/YYYY'
      });
  }

  ngOnInit() {
    this.submitted = false;
  }


  usersaveform = new FormGroup({
    user_firstname: new FormControl('', [Validators.required]),
    user_lastname: new FormControl('', [Validators.required]),
    user_email: new FormControl('', [Validators.required, Validators.email]),
    user_gender: new FormControl('', [Validators.required]),
    user_dateofbirth: new FormControl('', [Validators.required]),
    user_phone: new FormControl('', [Validators.required, Validators.pattern('[789][0-9]{9}')]),
    user_bloodgroup: new FormControl('', [Validators.required]),
    user_password: new FormControl('', [Validators.required, Validators.pattern('')]),
  });

  saveUser(saveUser) {
    this.user = new User();
    this.user.userFirstName = this.userFirstName.value;
    this.user.userLastName = this.userLastName.value;
    this.user.userGender = this.userGender.value;
    this.user.userDateOfBirth = this.userDateOfBirth.value;
    this.user.userPhone = this.userPhone.value;
    this.user.userBloodGroup = this.userBloodGroup.value;
    this.user.userEmail = this.userEmail.value;
    this.user.userPassword = this.userPassword.value;
    this.submitted = true;
    this.save();
  }

  save() {
    this.userService.createUser(this.user)
      .subscribe(data => {
        this.user = data
        console.log(data)
        if (this.user != null) {
          window.alert("Registration is successful! Thanks for registration.");
          this.usersaveform.reset();
        } else {
          window.alert("User already exist!")
        }
      }, error => console.log(error));
  }

  get userFirstName() {
    return this.usersaveform.get('user_firstname');
  }

  get userLastName() {
    return this.usersaveform.get('user_lastname');
  }

  get userEmail() {
    return this.usersaveform.get('user_email');
  }

  get userGender() {
    return this.usersaveform.get('user_gender');
  }

  get userDateOfBirth() {
    return this.usersaveform.get('user_dateofbirth');
  }

  get userPhone() {
    return this.usersaveform.get('user_phone');
  }

  get userBloodGroup() {
    return this.usersaveform.get('user_bloodgroup');
  }

  get userPassword() {
    return this.usersaveform.get('user_password');
  }

  adduserForm() {
    this.submitted = false;
    this.usersaveform.reset();
  }
} 