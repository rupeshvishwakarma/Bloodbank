export class Student {  
  
    student_id:number;  
    student_name:String;  
    student_email:String;  
    student_branch:String;  
    
}  