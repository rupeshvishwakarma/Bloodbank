import { Component, OnInit } from '@angular/core';
import { BloodRequestService } from './bloodrequest.service';
import { BloodRequest } from '../model/bloodrequest';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-bloodrequest',
  templateUrl: './bloodrequest.component.html',
  styleUrls: ['./bloodrequest.component.css']
})
export class BloodrequestComponent implements OnInit {

  submitted: boolean = false;

  bloodRequest: BloodRequest = new BloodRequest();

  constructor(private bloodRequestService: BloodRequestService) { }

  ngOnInit() {
  }

  bloodrequestsaveform = new FormGroup({
    patient_name: new FormControl('', [Validators.required]),
    patient_dateofbirth: new FormControl('', [Validators.required]),
    patient_gender: new FormControl('', [Validators.required]),
    patient_phone: new FormControl('', [Validators.required]),
    patient_bloodgroup: new FormControl('', [Validators.required]),
    patient_hospital: new FormControl('', [Validators.required]),
  });

  saveBloodrequest(saveBloodrequest) {
    this.bloodRequest = new BloodRequest();
    this.bloodRequest.patient_name = this.PatientName.value;
    this.bloodRequest.patient_dateofbirth = this.PatientDateOfBirth.value;
    this.bloodRequest.patient_gender = this.PatientGender.value;
    this.bloodRequest.patient_phone = this.PatientPhone.value;
    this.bloodRequest.patient_bloodgroup = this.PatientBloodGroup.value;
    this.bloodRequest.patient_hospital = this.PatientHospital.value;
    this.submitted = true;
    this.save();
    window.alert("Request is created!");
    this.bloodrequestsaveform.reset()
  }

  save() {
    this.bloodRequestService.createBloodRequest(this.bloodRequest)
      .subscribe(data => console.log(data), error => console.log(error));
    this.bloodRequest = new BloodRequest();
  }

  get PatientName() {
    return this.bloodrequestsaveform.get('patient_name');
  }

  get PatientDateOfBirth() {
    return this.bloodrequestsaveform.get('patient_dateofbirth');
  }

  get PatientGender() {
    return this.bloodrequestsaveform.get('patient_gender');
  }

  get PatientPhone() {
    return this.bloodrequestsaveform.get('patient_phone');
  }

  get PatientBloodGroup() {
    return this.bloodrequestsaveform.get('patient_bloodgroup');
  }

  get PatientHospital() {
    return this.bloodrequestsaveform.get('patient_hospital');
  }

}
