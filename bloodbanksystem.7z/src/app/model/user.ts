import { BloodRequest } from './bloodrequest';

export class User {

    userId: string;
    userFirstName: string;
    userLastName: string;
    userGender: string;
    userDateOfBirth: String;
    userPhone: String;
    userBloodGroup: string
    userEmail: string;
    userPassword: string;
    bloodRequests: BloodRequest[];
    
}