export class AdminLogin {

    adminLoginEmail: string;
    adminLoginPassword: string;

}