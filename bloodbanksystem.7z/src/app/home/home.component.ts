import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { AdminAuthenticationService } from './admin.authentication.service';
import { AdminLogin } from '../model/admin.login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  admin: AdminLogin;
  submitted: boolean = false;

  constructor(private adminAuthenticationService: AdminAuthenticationService,
    private router: Router) { }

  ngOnInit() {
    if (this.adminAuthenticationService.isUserLoggedIn()) {
      this.router.navigate(['admin-home']);
    }
  }

  adminloginform = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
  });


  adminLogin() {
    this.admin = new AdminLogin();
    this.admin.adminLoginEmail = this.adminloginform.get('username').value;
    this.admin.adminLoginPassword = this.adminloginform.get('password').value;
    this.submitted = true;
    this.save();
  }

  async save() {

    this.adminAuthenticationService.verifyAdmin(this.admin).subscribe(data => {
      this.admin = data;
      
      if (this.admin.adminLoginEmail != null) {
        sessionStorage.setItem('adminusername', this.admin.adminLoginEmail)
        this.router.navigate(['admin-home'])
      } else {
        window.alert("Wrong username or password!")
      }
      console.log(this.admin)
    }, error => console.log(error))

    console.log(this.admin)

  }

}
